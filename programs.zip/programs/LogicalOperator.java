package com.gboxz.java;

public class LogicalOperator {

    public static void main(String[] args) {
        boolean a = false;
        boolean b = true;

        // AND Operator
        System.out.println(a && b); // false AND true = false
        // OR Operator
        System.out.println(a || b); // false OR true = true
        // XOR Operator
        System.out.println(a ^ b); // false XOR true = true
        // NOT Operator
        System.out.println(!a); // NOT true = false

    }
}
