package com.gboxz.java;

public class BitwiseOperator {

    public static void main(String[] args) {
        int a = 10;
        int b = 4;
        
        // AND Operator
        System.out.println(a & b); // 0
        // OR Operator
        System.out.println(a | b); // 14
        // XOR Operator
        System.out.println(a ^ b); // 14


    }
}
