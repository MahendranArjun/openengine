package com.gboxz.java;

public class DataType {

    public static void main(String[] args) {

        int a = 1; // 4 Byte
        float b = 2.0F; // 4 Byte
        long c = 3L; // 8 Byte
        double d = 4D; // 8 Byte
        boolean e = false; // 1 Bite
        short f = 10; // 2 Byte
        byte g = 4; // 1 Byte
        byte h = 'b';
        char i = 'a';

    }
}