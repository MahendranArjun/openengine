package com.gboxz.http.core.http

import java.io.InputStream
import java.io.OutputStream

interface Request {

    val url: String
    val method: String
    val headers: Map<String, String>
    val body: Body
    val responseReader: ResponseReader get() = SimpleResponseReader()

    interface Body {
        fun contentLength(): Long
        fun contentType(): String
        fun writeTo(sink: OutputStream)
    }


    interface ResponseReader {
        fun read(contentLength: Long, contentType: String, source: InputStream): ByteArray
    }


    class SimpleResponseReader : ResponseReader {
        override fun read(
            contentLength: Long,
            contentType: String,
            source: InputStream
        ): ByteArray = source.readBytes()

    }

    class SimpleBody(private val body: ByteArray, private val contentType: String) : Body {

        override fun contentLength() = body.size.toLong()

        override fun contentType(): String = contentType

        override fun writeTo(sink: OutputStream) {
            sink.write(body)
        }

    }

}