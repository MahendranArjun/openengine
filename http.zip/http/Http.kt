package com.gboxz.http.core.http

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.*
import kotlin.collections.HashMap

object Http {


    private fun makeConnection(url: String): HttpURLConnection {
        return URL(url).openConnection() as HttpURLConnection
    }

    private fun HttpURLConnection.configureConnection(
        method: String,
        headers: Map<String, String>,
        body: Request.Body
    ): HttpURLConnection {
        doOutput = true
        requestMethod = method.toUpperCase(Locale.getDefault())
        headers.withRequestBody(body).map { (key, value) -> setRequestProperty(key, value) }
        return this
    }


    private fun HttpURLConnection.write(body: Request.Body): HttpURLConnection {

        outputStream.use {
            body.writeTo(it)
            it.flush()
        }

        return this
    }

    private fun HttpURLConnection.readAndClose(request: Request): Response {
        val headers = headerFields.map { it.key to it.value.first() }.toMap()
        val contentLength = headers["Content-Length"]?.toLong() ?: 0L
        val contentType = headers["Content-Type"] ?: ""
        val content =
            inputStream.use { request.responseReader.read(contentLength, contentType, it) }
        return Response(
            request,
            headers,
            responseCode,
            Response.Body(contentLength, contentType, String(content))
        )
    }

    private fun Map<String, String>.withRequestBody(body: Request.Body): Map<String, String> {
        val headers = HashMap(this)
        headers["Content-Type"] = body.contentType()
        headers["Content-Length"] = "${body.contentLength()}"
        return headers
    }

    @Throws(IOException::class)
    fun request(request: Request): Response {
        return makeConnection(request.url)
            .configureConnection(request.method, request.headers, request.body)
            .write(request.body)
            .readAndClose(request)

    }


}