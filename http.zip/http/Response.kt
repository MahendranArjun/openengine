package com.gboxz.http.core.http


data class Response(
        val request:Request,
        val headers: Map<String, String>,
        val status: Int,
        val body: Body
    ) {

    data class Body(val contentLength:Long, val contentType:String, val content:String)
}
