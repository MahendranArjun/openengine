package com.gboxz.http.core.http.request

import com.gboxz.http.core.http.Request
import java.io.*

class DownloadRequest(
    override val url: String,
    override val method: String,
    destination: File,
    override val body: Request.Body,
    override val headers: Map<String, String> = emptyMap(),
    bufferSize:Int = DEFAULT_BUFFER_SIZE,
    progressListener: ProgressListener? = null

) :Request {


    override val responseReader: Request.ResponseReader =
        FileDownloader(destination, bufferSize, progressListener)


    private class FileDownloader(
        private val file: File,
        private val bufferSize: Int,
        private val progressListener: ProgressListener?
    ) : Request.ResponseReader {


        private fun InputStream.read(size: Long, file: File) {
            FileOutputStream(file).use { writer ->
                var completed = 0L
                var read = 0
                val buffer = ByteArray(bufferSize)
                onProgress(size, completed)
                while (read(buffer).also { read = it } > 0) {
                    writer.write(buffer, 0, read)
                    completed += read
                    onProgress(size, completed)
                }
            }
        }

        private fun onProgress(total: Long, completed: Long) {
            progressListener?.onProgress(total, completed)
        }

        override fun read(
            contentLength: Long,
            contentType: String,
            source: InputStream
        ): ByteArray {
            source.read(contentLength, file)
            return byteArrayOf()
        }

    }

    fun interface ProgressListener {
        fun onProgress(total: Long, completed: Long)
    }


    companion object {
        private const val DEFAULT_BUFFER_SIZE = 1024
    }

}