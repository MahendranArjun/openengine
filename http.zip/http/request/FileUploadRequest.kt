package com.gboxz.http.core.http.request

import com.gboxz.http.core.http.Request
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream

class FileUploadRequest(
    override val url: String,
    override val method: String,
    source: File,
    override val headers: Map<String, String> = emptyMap(),
    boundary:String = DEFAULT_BOUNDARY,
    bufferSize:Int = DEFAULT_BUFFER_SIZE,
    progressListener: ProgressListener? = null
) :Request {


    override val body: Request.Body = FileUploader(source, boundary, bufferSize, progressListener)


    private class FileUploader(
        private val file: File,
        private val boundary: String,
        private val bufferSize: Int,
        private val progressListener: ProgressListener?
    ) : Request.Body {


        override fun contentLength() = file.length()
        override fun contentType(): String = "multipart/form-data;boundary=${boundary}"
        override fun writeTo(sink: OutputStream) {


            val name = file.nameWithoutExtension
            val fileName = file.name

            val outputStream = DataOutputStream(sink)
            outputStream.writeBytes(TWO_HYPHENS + boundary + CRLF)
            outputStream.writeBytes(
                """Content-Disposition: form-data; name="$name";filename="$fileName"$CRLF"""
            )
            outputStream.writeBytes(CRLF)
        }


        private fun OutputStream.write(file: File) {
            FileInputStream(file).use { reader ->
                val size = contentLength()
                var completed = 0L
                var read = 0
                val buffer = ByteArray(bufferSize)
                onProgress(size, completed)
                while (reader.read(buffer).also { read = it } > 0) {
                    write(buffer, 0, read)
                    completed += read
                    onProgress(size, completed)
                }

            }
        }

        private fun onProgress(total: Long, completed: Long) {
            progressListener?.onProgress(total, completed)
        }

    }

    fun interface ProgressListener {
        fun onProgress(total: Long, completed: Long)
    }


    companion object {
        private const val CRLF = "\r\n"
        private const val TWO_HYPHENS = "--"
        private const val DEFAULT_BOUNDARY = "*****"
        private const val DEFAULT_BUFFER_SIZE = 1024
    }

}