package com.gboxz.java;

public class InfiniteWhile {

    public static void main(String[] args) {
        while (true) {
            System.out.println("infinitive while loop");
        }
    }
}
