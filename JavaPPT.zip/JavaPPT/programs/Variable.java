package com.gboxz.java;

public class Variable {
    int data = 50; // instance variable
    static int m = 100; // static variable

    public static void main(String[] args) {
        int n = 90; // local variable
    }
}
