package com.gboxz.java;

public class ShiftOperator {

    public static void main(String[] args) {

        System.out.println(10 << 2); // Left shift
        System.out.println(10 >> 2); // Right shift

        System.out.println(10 >>> 2); // Right shift
    }
}
