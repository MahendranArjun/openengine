package com.gboxz.http.core.handler

import com.gboxz.http.core.request.Request


interface HttpRetryHandler {
    fun handle(attemptCount: Int, request: Request<*>)
}