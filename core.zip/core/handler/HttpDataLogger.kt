package com.gboxz.http.core.handler

import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response

interface HttpDataLogger {
    fun request(request: Request<*>)
    fun response(response: Response<*>, request: Request<*>)
    fun error(error: Exception, request: Request<*>)
}

