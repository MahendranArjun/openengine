package com.gboxz.http.core.handler

import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response


interface HttpResponseHandler {
    fun response(response: Response<Any>, request: Request<*>):Response<Any>
    fun error(error: Exception, request: Request<*>):Exception
}