package com.gboxz.http.core.handler

import com.gboxz.http.core.request.Request


interface HttpDataFormatter {

    val contentType:String


    fun serialize(data: Any?, request: Request<*>): String?
    fun deserialize(data: String?, request: Request<*>): Any?
}