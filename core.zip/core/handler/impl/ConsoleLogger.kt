package com.gboxz.http.core.handler.impl

import android.util.Log
import com.gboxz.http.core.handler.HttpDataLogger
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response

class ConsoleLogger:HttpDataLogger {
    override fun request(request: Request<*>) {
        Log.d("Http", "Request => $request")
    }

    override fun response(response: Response<*>, request: Request<*>) {
        Log.d("Http", "Request => $request Response => $response")
    }

    override fun error(error: Exception, request: Request<*>) {
        Log.d("Http", "Request => $request Error => $error")
    }
}