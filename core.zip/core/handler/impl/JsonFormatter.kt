package com.gboxz.http.core.handler.impl


import com.gboxz.http.core.handler.HttpDataFormatter
import com.gboxz.http.core.request.Request
import com.google.gson.GsonBuilder

class JsonFormatter : HttpDataFormatter {

    private val gson = GsonBuilder().create()
    override val contentType: String = "application/json"


    override fun serialize(data: Any?, request: Request<*>): String? {

        return gson.toJson(data)
    }

    override fun deserialize(data: String?, request: Request<*>): Any? {
        return gson.fromJson(data, request.type)
    }
}