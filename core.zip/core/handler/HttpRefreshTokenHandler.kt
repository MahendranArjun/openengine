package com.gboxz.http.core.handler


interface HttpRefreshTokenHandler {
    fun onExpire()
    fun onRetrieve()
}