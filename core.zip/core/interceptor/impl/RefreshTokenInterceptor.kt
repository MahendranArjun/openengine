package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response

class RefreshTokenInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_REFRESH_TOKEN_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {
        println("Interceptor = $id")

        val result = chain.proceed(chain.request)
        if (result.code == 401) {
            chain.authenticator.refreshToken(chain.repository.id)
        }
        return result
    }


}