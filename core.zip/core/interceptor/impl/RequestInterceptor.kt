package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response

class RequestInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_REQUEST_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {


        var request = chain.request

        println("Body = ${request.body}")
        if (chain.request.options.requestHandlerOrder.isEmpty()) {
            chain.repository.httpRequestHandlers.forEach {
                request = it.handle(request)
            }
        } else {
            chain.request.options.requestHandlerOrder.forEach {
                request = chain.repository.httpRequestHandlers[it].handle(request)
            }
        }

        val headers = request.headers.toMutableMap()

        val httpDataFormatter = chain.repository.httpDataFormatter

        if (httpDataFormatter!=null){
            headers["Content-Type"] = httpDataFormatter.contentType
        }

        if (request.options.withToken) {

            val token = chain.authenticator.getToken(id)

            chain.authenticator.getAuthentication(id)?.also {
                headers["Authentication"] = "${it.scheme} $token"
            }
            request = request.copy(headers = headers)
        }

        return chain.proceed(request)

    }


}