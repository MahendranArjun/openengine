package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response
import kotlin.Exception

class ResponseInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_RESPONSE_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {
        println("Interceptor = $id")


        val httpResponseHandler = chain.repository.httpResponseHandler
        return try {
            httpResponseHandler?.response(chain.proceed(chain.request), chain.request)
                ?: chain.proceed(chain.request)
        } catch (e: Exception) {
            throw httpResponseHandler?.error(e, chain.request)!!
        }
    }


}