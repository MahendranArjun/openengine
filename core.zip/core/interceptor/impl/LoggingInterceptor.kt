package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response
import java.lang.IllegalArgumentException
import kotlin.Exception

class LoggingInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_LOGGING_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {
        println("Interceptor = $id")

        val logger = chain.repository.httpDataLogger
        val request = chain.request
        return if (logger != null) {
            logger.request(request)
            try {
                chain.proceed(request).also {
                    logger.response(it, request)
                }
            } catch (e: Exception) {
                logger.error(e, chain.request)
                throw e
            }
        } else {
            chain.proceed(request)
        }


    }


}