package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response
import java.lang.IllegalArgumentException

class DeserializationInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_DESERIALIZATION_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {
        println("Interceptor = $id")
        val httpDataFormatter = chain.repository.httpDataFormatter?:throw IllegalArgumentException("No HttpDataFormatter provided")
        val result  =  chain.proceed(chain.request)
        return result.copy(body = httpDataFormatter.deserialize(result.body as String, chain.request)).apply {
            println("Out Interceptor = $id")
        }
    }


}