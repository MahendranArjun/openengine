package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response
import java.lang.IllegalArgumentException

class DataCoderInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_CODER_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {
        println("Interceptor = $id")

        val httpDataCoder = chain.repository.httpDataCoder
            ?: throw IllegalArgumentException("No HttpDataFormatter provided")

        val request = chain.request.copy(
            body = httpDataCoder.encode(
                chain.request.body as String,
                chain.request
            )
        )
        val result = chain.proceed(request)
        return result.copy(body = httpDataCoder.decode(result.body as String, request))
    }

}