package com.gboxz.http.core.authentication.impl

import com.gboxz.http.core.authentication.Authentication
import com.gboxz.http.core.authentication.Authenticator
import com.gboxz.http.core.authentication.OAuthentication

internal class AuthenticatorImpl(private val authentications: List<Authentication>):
    Authenticator {


    private val tokens = mutableMapOf<String,String>()

    override suspend fun authenticate(repositoryId: String, body: Any?): String {
        val result = getAuthentication(repositoryId)?.authenticate(body)?:throw IllegalArgumentException("Invalid repository id")
        tokens[repositoryId] = result
        return result
    }

    override suspend fun refreshToken(repositoryId: String, body: Any?): String {
        val authentication = getAuthentication(repositoryId)?: throw IllegalArgumentException("Invalid repository id")

        if (authentication is OAuthentication) {
            val result =authentication.refreshToken(body)
            tokens[repositoryId] = result
            return result
        }
        throw IllegalArgumentException("Invalid repository id")
    }

    override fun getToken(repositoryId: String): String?  = tokens[repositoryId]
    override fun getAuthentication(repositoryId: String): Authentication? = authentications.find { it.repositoryId == repositoryId }

    override fun dispose(repositoryId: String) {
        tokens.remove(repositoryId)
    }

    override fun disposeAll() {
        tokens.clear()
    }

}