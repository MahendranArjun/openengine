package com.gboxz.http.core.authentication

import com.gboxz.http.core.authentication.Authentication

interface OAuthentication : Authentication{
    suspend fun refreshToken(body:Any?):String
}