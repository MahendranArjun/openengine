package com.gboxz.http.core.authentication


interface Authenticator {

    suspend fun authenticate(repositoryId: String, body: Any? = null): String
    suspend fun refreshToken(repositoryId: String, body: Any? = null): String
    fun getToken(repositoryId: String): String?
    fun getAuthentication(repositoryId: String): Authentication?
    fun dispose(repositoryId: String)
    fun disposeAll()


}