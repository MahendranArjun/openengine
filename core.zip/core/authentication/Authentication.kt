package com.gboxz.http.core.authentication

interface Authentication {

    val repositoryId:String
    val scheme:Scheme
    suspend fun authenticate(body:Any?):String
    fun logout()

    enum class Scheme {
        Basic, Bearer, Digest, HOBA, Mutual, AWS4_HMAC_SHA256
    }
}