package com.gboxz.http.core.response

import com.gboxz.http.core.util.Headers

data class Response<out T>(val body:T?, val headers: Headers, val code:Int, val message:String) {

}