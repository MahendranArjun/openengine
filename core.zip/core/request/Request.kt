package com.gboxz.http.core.request

import com.gboxz.http.core.util.Headers
import com.gboxz.http.core.util.Params
import java.lang.reflect.Type

data class Request<out T> (
    val url: String,
    val method: Method,
    val body: T?,
    val type: Type,
    val headers: Headers = emptyMap(),
    val params: Params?,
    val options:Options = Options()
) {

    data class Options(
        val timeout: Int = 25000,
        val repositoryId: String? = null,
        val reportLoading: Boolean = false,
        val withToken: Boolean = false,
        val requestHandlerOrder: List<Int> = emptyList(),
        val interceptorToSkip: List<String> = emptyList(),
        val extra: Any? = null
    )

    enum class Method {
        Get, Post, Put, Head, Delete, Patch
    }


}