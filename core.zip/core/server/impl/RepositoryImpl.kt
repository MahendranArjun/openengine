package com.gboxz.http.core.server.impl

import com.gboxz.http.core.handler.*
import com.gboxz.http.core.server.Repository

internal data class RepositoryImpl(
        override val id: String,
        override val name: String,
        override val baseUrl: String,
        override val timeout: Int,
        override val retryCount: Int,
        override val useDefaultFormatter: Boolean,
        override val useDefaultCoder: Boolean,
        override val useDefaultLogger: Boolean,
        override val httpDataCoder: HttpDataCoder?,
        override val httpDataFormatter: HttpDataFormatter?,
        override val httpDataLogger: HttpDataLogger?,
        override val httpRefreshTokenHandler: HttpRefreshTokenHandler?,
        override val httpRequestHandlers: List<HttpRequestHandler>,
        override val httpResponseHandler: HttpResponseHandler?,
        override val httpRetryHandler: HttpRetryHandler?
) : Repository