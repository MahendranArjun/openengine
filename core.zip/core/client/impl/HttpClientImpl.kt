package com.gboxz.http.core.client.impl

import com.gboxz.http.core.authentication.Authenticator
import com.gboxz.http.core.call.Call
import com.gboxz.http.core.client.HttpClient
import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.interceptor.chain.ChainImpl
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.server.Repository

internal class HttpClientImpl(override val authenticator: Authenticator, private val interceptors:List<Interceptor>, private val call: Call, private val repositories: List<Repository>) : HttpClient {
    override suspend fun <IN, OUT> request(request: Request<IN>): Response<OUT> {
        if (repositories.isEmpty()) throw IllegalArgumentException("At least need one Repository")
        val interceptors = interceptors.dropWhile { it.id in request.options.interceptorToSkip }
        if (interceptors.isEmpty()) throw IllegalArgumentException("At least need one Interceptor")

        val repository =
            repositories.find { it.id == request.options.repositoryId } ?: repositories.first()
        val chain =
            ChainImpl(1, interceptors, request as Request<Any>, call, repository, authenticator)
        return interceptors.first().intercept(chain) as Response<OUT>
    }
}