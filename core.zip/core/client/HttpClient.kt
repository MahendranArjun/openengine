package com.gboxz.http.core.client

import com.gboxz.http.core.authentication.Authentication
import com.gboxz.http.core.authentication.Authenticator
import com.gboxz.http.core.authentication.impl.AuthenticatorImpl
import com.gboxz.http.core.call.Call
import com.gboxz.http.core.call.impl.CallImpl
import com.gboxz.http.core.client.impl.HttpClientImpl
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.server.Repository
import com.gboxz.http.core.util.Headers
import com.gboxz.http.core.util.Params
import java.lang.IllegalArgumentException
import java.lang.reflect.Type


interface HttpClient {

    val authenticator: Authenticator
    suspend fun <IN, OUT> request(request: Request<IN>): Response<OUT>

    suspend fun <IN, OUT> post(
        url: String,
        type: Type,
        body: IN? = null,
        headers: Headers = emptyMap(),
        params: Params? = null,
        options: Request.Options? = null
    ): Response<OUT> {
        return request(Request(url, Request.Method.Post, body, type, headers, params))
    }


    suspend fun <OUT> get(
        url: String,
        type: Type,
        body: Any? = null,
        headers: Headers = emptyMap(),
        params: Params? = null,
        options: Request.Options? = null
    ): Response<OUT> {
        return request(Request(url, Request.Method.Get, body, type, headers, params))
    }

    suspend fun <OUT> delete(
        url: String,
        type: Type,
        body: Any? = null,
        headers: Headers = emptyMap(),
        params: Params? = null,
        options: Request.Options? = null
    ): Response<OUT> {
        return request(Request(url, Request.Method.Delete, body, type, headers, params))
    }


    suspend fun <IN, OUT> patch(
        url: String,
        type: Type,
        body: IN? = null,
        headers: Headers = emptyMap(),
        params: Params? = null,
        options: Request.Options? = null
    ): Response<OUT> {
        return request(Request(url, Request.Method.Patch, body, type, headers, params))
    }


    suspend fun <IN, OUT> head(
        url: String,
        type: Type,
        body: IN? = null,
        headers: Headers = emptyMap(),
        params: Params? = null,
        options: Request.Options? = null
    ): Response<OUT> {
        return request(Request(url, Request.Method.Head, body, type, headers, params))
    }


    class Builder {

        private var httpInterceptors: HttpInterceptors = HttpInterceptors.default()
        private var call: Call = CallImpl()
        private val repositories = mutableListOf<Repository>()
        private val authentications = mutableListOf<Authentication>()

        fun httpInterceptors(httpInterceptors: HttpInterceptors): Builder {
            this.httpInterceptors = httpInterceptors
            return this
        }

        fun call(call: Call): Builder {
            this.call = call
            return this
        }

        fun addRepository(repository: Repository): Builder {
            this.repositories.add(repository)
            return this
        }

        fun addAuthentication(authentication: Authentication): Builder {
            this.authentications.add(authentication)
            return this
        }


        fun build(): HttpClient {
            if (repositories.isEmpty()) throw IllegalArgumentException("At least need one repository")
            return HttpClientImpl(
                AuthenticatorImpl(authentications),
                httpInterceptors.interceptors,
                call,
                repositories
            )
        }
    }


}