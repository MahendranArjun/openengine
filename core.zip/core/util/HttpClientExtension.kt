package com.gboxz.http.core.util

import com.gboxz.http.core.client.HttpClient
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response


suspend inline fun <reified OUT> HttpClient.post(
    url: String,
    body: Any? = null,
    headers: Headers = emptyMap(),
    params: Params? = null,
    options: Request.Options? = null
): Response<OUT> {
    return post(url, OUT::class.java, body, headers, params, options)
}


suspend inline fun < reified OUT> HttpClient.get(
    url: String,
    body: Any? = null,
    headers: Headers = emptyMap(),
    params: Params? = null,
    options: Request.Options? = null
): Response<OUT> {
    return get(url, OUT::class.java, body, headers, params, options)
}

suspend inline fun < reified OUT> HttpClient.delete(
    url: String,
    body: Any? = null,
    headers: Headers = emptyMap(),
    params: Params? = null,
    options: Request.Options? = null
): Response<OUT> {
    return delete(url, OUT::class.java, body, headers, params, options)
}



suspend inline fun < reified OUT> HttpClient.patch(
    url: String,
    body: Any? = null,
    headers: Headers = emptyMap(),
    params: Params? = null,
    options: Request.Options? = null
): Response<OUT> {
    return patch(url, OUT::class.java, body, headers, params, options)
}


suspend inline fun < reified OUT> HttpClient.head(
    url: String,
    body: Any? = null,
    headers: Headers = emptyMap(),
    params: Params? = null,
    options: Request.Options? = null
): Response<OUT> {
    return head(url, OUT::class.java, body, headers, params, options)
}
