package com.gboxz.http.core.util

typealias Params =  Map<String, String>