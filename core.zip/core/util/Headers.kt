package com.gboxz.http.core.util

typealias Headers =  Map<String, String>