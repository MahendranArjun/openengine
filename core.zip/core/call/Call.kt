package com.gboxz.http.core.call

import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.server.Repository

interface Call {
    suspend operator fun invoke(repository: Repository, request: Request<String>): Response<String>
}