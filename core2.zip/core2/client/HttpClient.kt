package com.gboxz.http.core.client

import com.gboxz.http.core.authentication.Authentication
import com.gboxz.http.core.authentication.Authenticator
import com.gboxz.http.core.authentication.impl.AuthenticatorImpl
import com.gboxz.http.core.call.Call
import com.gboxz.http.core.call.impl.CallImpl
import com.gboxz.http.core.client.impl.HttpClientImpl
import com.gboxz.http.core.request.DataRequest
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.server.Repository
import com.gboxz.http.core.util.Headers
import com.gboxz.http.core.util.Params
import java.lang.IllegalArgumentException
import java.lang.reflect.Type


interface HttpClient {

    val authenticator: Authenticator

    suspend fun <OUT> request(request: Request<Any?>): Response<OUT>
    suspend fun <OUT> request(request: DataRequest<Any, OUT>): Response<OUT> = request(request as Request<Any?>)


    suspend fun <OUT> post(
        url: String,
        body: Any?,
        type: Class<out OUT>,
        id: String? = null,
        headers: Headers = emptyMap(),
        params: Params = emptyMap(),
        options: Request<Any?>.Options = Request.Options()
    ): Response<OUT> {
        return request(Request(url, Request.Method.Post, type, body, id, headers, params, options))
    }

    suspend fun <OUT> put(
        url: String,
        body: Any?,
        type: Class<out OUT>,
        id: String? = null,
        headers: Headers = emptyMap(),
        params: Params = emptyMap(),
        options: Request<Any?>.Options = Request.Options()
    ): Response<OUT> {
        return request(Request(url, Request.Method.Put, type, body, id, headers, params, options))
    }

    suspend fun <OUT> patch(
        url: String,
        body: Any?,
        type: Class<out OUT>,
        id: String? = null,
        headers: Headers = emptyMap(),
        params: Params = emptyMap(),
        options: Request<Any?>.Options = Request.Options()
    ): Response<OUT> {
        return request(Request(url, Request.Method.Patch, type, body, id, headers, params, options))
    }

    suspend fun <OUT> get(
        url: String,
        type: Class<out OUT>,
        id: String? = null,
        headers: Headers = emptyMap(),
        params: Params = emptyMap(),
        options: Request<Any?>.Options = Request.Options()
    ): Response<OUT> {
        return request(Request(url, Request.Method.Get, type, null, id, headers, params, options))
    }

    suspend fun <OUT> delete(
        url: String,
        type: Class<out OUT>,
        id: String? = null,
        headers: Headers = emptyMap(),
        params: Params = emptyMap(),
        options: Request<Any?>.Options = Request.Options()
    ): Response<OUT> {
        return request(
            Request(
                url,
                Request.Method.Delete,
                type,
                null,
                id,
                headers,
                params,
                options
            )
        )
    }

    suspend fun <OUT> head(
        url: String,
        type: Class<out OUT>,
        id: String? = null,
        headers: Headers = emptyMap(),
        params: Params = emptyMap(),
        options: Request<Any?>.Options = Request.Options()
    ): Response<OUT> {
        return request(Request(url, Request.Method.Head, type, null, id, headers, params, options))
    }


    class Builder {

        private var httpInterceptors: HttpInterceptors = HttpInterceptors.default()
        private var call: Call = CallImpl()
        private val repositories = mutableListOf<Repository>()
        private val authentications = mutableListOf<Authentication>()

        fun httpInterceptors(httpInterceptors: HttpInterceptors): Builder {
            this.httpInterceptors = httpInterceptors
            return this
        }

        fun call(call: Call): Builder {
            this.call = call
            return this
        }

        fun addRepository(repository: Repository): Builder {
            this.repositories.add(repository)
            return this
        }

        fun addAuthentication(authentication: Authentication): Builder {
            this.authentications.add(authentication)
            return this
        }


        fun build(): HttpClient {
            if (repositories.isEmpty()) throw IllegalArgumentException("At least need one repository")
            return HttpClientImpl(
                AuthenticatorImpl(authentications),
                httpInterceptors.interceptors,
                call,
                repositories
            )
        }
    }


}