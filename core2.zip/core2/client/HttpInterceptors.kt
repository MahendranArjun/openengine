package com.gboxz.http.core.client

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.interceptor.impl.*

class HttpInterceptors private constructor(internal val interceptors: List<Interceptor>) {


    class Builder {

        private val interceptors = mutableListOf<Interceptor>()


        fun request(): Builder {
            interceptors.add(RequestInterceptor())
            return this
        }

        fun serialization(): Builder {
            interceptors.add(SerializationInterceptor())
            return this
        }


        fun logger(): Builder {
            interceptors.add(LoggingInterceptor())
            return this
        }


        fun response(): Builder {
            interceptors.add(ResponseInterceptor())
            return this
        }

        fun refreshToken(): Builder {
            interceptors.add(RefreshTokenInterceptor())
            return this
        }


        fun deserialization(): Builder {
            interceptors.add(DeserializationInterceptor())
            return this
        }


        fun custom(interceptor: Interceptor): Builder {
            interceptors.add(interceptor)
            return this
        }

        fun build(): HttpInterceptors =
            HttpInterceptors(interceptors + ServerCallInterceptor())
    }

    companion object {

        fun default() = Builder().build()
    }

}