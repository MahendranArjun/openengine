package com.gboxz.http.core.server

import com.gboxz.http.core.handler.*
import com.gboxz.http.core.handler.impl.JsonFormatter
import com.gboxz.http.core.server.impl.RepositoryImpl

interface Repository {
    val id: String
    val name: String
    val baseUrl: String
    val timeout: Int
    val retryCount: Int
    val useDefaultFormatter: Boolean
    val useDefaultCoder: Boolean
    val useDefaultLogger: Boolean

    val httpDataCoder: HttpDataCoder?
    val httpDataFormatter: HttpDataFormatter?
    val httpDataLogger: HttpDataLogger?
    val httpRefreshTokenHandler: HttpRefreshTokenHandler?
    val httpRequestHandlers: List<HttpRequestHandler>
    val httpResponseHandler: HttpResponseHandler?
    val httpRetryHandler: HttpRetryHandler?



    class Builder(
        private var baseUrl: String,
        private var name: String,
        private var id: String
    ) {


        private var httpDataCoder: HttpDataCoder? = null
        private var httpDataFormatter: HttpDataFormatter? = JsonFormatter()
        private var httpDataLogger: HttpDataLogger? = null
        private var httpRefreshTokenHandler: HttpRefreshTokenHandler? = null
        private val httpRequestHandlers: MutableList<HttpRequestHandler> = mutableListOf()
        private var httpResponseHandler: HttpResponseHandler? = null
        private var httpRetryHandler: HttpRetryHandler? = null

        private var timeout: Int = 25000
        private var retryCount: Int = 1

        private val useDefaultFormatter: Boolean = true
        private val useDefaultCoder: Boolean = true
        private val useDefaultLogger: Boolean = true


        fun setBaseUrl(baseUrl: String): Builder {
            this.baseUrl = baseUrl
            return this
        }

        fun setName(name: String): Builder {
            this.name = name
            return this
        }

        fun setId(id: String): Builder {
            this.id = id
            return this
        }

        fun setTimeout(timeout: Int): Builder {
            this.timeout = timeout
            return this
        }


        fun setHttpDataCoder(httpDataCoder: HttpDataCoder): Builder {
            this.httpDataCoder = httpDataCoder
            return this
        }

        fun setHttpDataFormatter(httpDataFormatter: HttpDataFormatter): Builder {
            this.httpDataFormatter = httpDataFormatter
            return this
        }

        fun setHttpDataLogger(httpDataLogger: HttpDataLogger): Builder {
            this.httpDataLogger = httpDataLogger
            return this
        }

        fun setHttpRefreshTokenHandler(httpRefreshTokenHandler: HttpRefreshTokenHandler): Builder {
            this.httpRefreshTokenHandler = httpRefreshTokenHandler
            return this
        }

        fun addHttpRequestHandler(httpRequestHandler: HttpRequestHandler): Builder {
            httpRequestHandlers.add(httpRequestHandler)
            return this
        }

        fun setHttpResponseHandler(httpResponseHandler: HttpResponseHandler): Builder {
            this.httpResponseHandler = httpResponseHandler
            return this
        }

        fun setHttpRetryHandler(httpRetryHandler: HttpRetryHandler): Builder {
            this.httpRetryHandler = httpRetryHandler
            return this
        }


        fun build(): Repository = RepositoryImpl(
            id, name, baseUrl, timeout, retryCount, useDefaultFormatter, useDefaultCoder, useDefaultLogger, httpDataCoder, httpDataFormatter, httpDataLogger, httpRefreshTokenHandler, httpRequestHandlers, httpResponseHandler, httpRetryHandler
        )
    }



}