package com.gboxz.http.core.error

import com.gboxz.http.core.server.Repository

sealed class HttpError(message: String) : Exception(message)
data class AuthenticationError(val repositoryId:String, override val message: String) : HttpError(message)
data class NetworkError(override val message: String) : HttpError(message)



