package com.gboxz.http.core.response

import com.gboxz.http.core.util.Headers

data class NetworkResponse(val url: String,
                           val headers: Headers,
                           val code: Int,
                           val message: String)