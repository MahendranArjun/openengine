package com.gboxz.http.core.response

fun interface Transformer<in S,out R> {
    fun transform(source: S): R
}