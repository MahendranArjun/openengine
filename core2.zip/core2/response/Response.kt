package com.gboxz.http.core.response

import com.gboxz.http.core.error.HttpError
import com.gboxz.http.core.util.Headers
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.contract

sealed class Response<out T> {


    abstract val networkResponse: NetworkResponse?


    data class Success<out T>(
        val body: T?, override val networkResponse: NetworkResponse,
    ) : Response<T>()

    data class Failure(
        val error: HttpError, override val networkResponse: NetworkResponse?,
    ) : Response<Nothing>()


    @OptIn(ExperimentalContracts::class)
    fun isSuccess(): Boolean {
        contract { returns(true) implies (this@Response is Success) }
        return this is Success
    }

    @OptIn(ExperimentalContracts::class)
    fun isFailure(): Boolean {
        contract { returns(true) implies (this@Response is Failure) }
        return this is Failure
    }


    suspend fun onSuccess(listener: suspend Success<T>.() -> Unit): Response<T> {
        if (this is Success) listener(this)
        return this
    }

    suspend fun onFailure(listener: suspend Failure.() -> Unit): Response<T> {
        if (this is Failure) listener(this)
        return this
    }


}