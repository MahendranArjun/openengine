package com.gboxz.http.core.interceptor.chain

import com.gboxz.http.core.authentication.Authenticator
import com.gboxz.http.core.call.Call
import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.server.Repository

internal data class ChainImpl(
    private val index:Int,
    private val interceptors: List<Interceptor>,
    override val request: Request<Any?>,
    override val call: Call,
    override val repository: Repository,
    override val authenticator: Authenticator
    ): Interceptor.Chain {

    override suspend fun proceed(request: Request<Any?>): Response<Any> {
        if (index >= interceptors.size) throw IllegalArgumentException("Invalid interceptors size")
        val chain = ChainImpl(
            index + 1,
            interceptors,
            request,
            call,
            repository,
            authenticator
        )
        return interceptors[index].intercept(chain)
    }
}