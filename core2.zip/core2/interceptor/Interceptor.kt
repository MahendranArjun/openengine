package com.gboxz.http.core.interceptor


import com.gboxz.http.core.authentication.Authenticator
import com.gboxz.http.core.call.Call
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.server.Repository

interface Interceptor {

    val id: String
    suspend fun intercept(chain: Chain): Response<Any>

    interface Chain {

        val request: Request<Any?>
        val call: Call
        val repository: Repository
        val authenticator: Authenticator

        suspend fun proceed(request: Request<Any?>): Response<Any>
    }

    companion object {

        const val ID_REPORT_INTERCEPTOR ="Interceptor.ID_REPORT_INTERCEPTOR"
        const val ID_REQUEST_INTERCEPTOR ="Interceptor.ID_REQUEST_INTERCEPTOR"
        const val ID_SERIALIZATION_INTERCEPTOR ="Interceptor.ID_SERIALIZATION_INTERCEPTOR"
        const val ID_REFRESH_TOKEN_INTERCEPTOR ="Interceptor.ID_REFRESH_TOKEN_INTERCEPTOR"
        const val ID_LOGGING_INTERCEPTOR ="Interceptor.ID_LOGGING_INTERCEPTOR"
        const val ID_RESPONSE_INTERCEPTOR ="Interceptor.ID_RESPONSE_INTERCEPTOR"
        const val ID_DESERIALIZATION_INTERCEPTOR ="Interceptor.ID_DESERIALIZATION_INTERCEPTOR"
        const val ID_CODER_INTERCEPTOR ="Interceptor.ID_CODER_INTERCEPTOR"
        const val ID_SERVER_INTERCEPTOR ="Interceptor.ID_SERVER_INTERCEPTOR"

    }

}