package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.util.transform
import com.gboxz.http.core.util.transformIfNotNull
import kotlin.Exception

class ResponseInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_RESPONSE_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {


        return chain.proceed(chain.request).transformIfNotNull {
            when (it) {
                is Response.Success -> chain.repository.httpResponseHandler?.response(
                    it,
                    chain.request
                )
                is Response.Failure -> chain.repository.httpResponseHandler?.error(
                    it,
                    chain.request
                )
            }

        }
    }


}