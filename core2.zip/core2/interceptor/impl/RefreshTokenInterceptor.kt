package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.error.AuthenticationError
import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.request.Request.Companion.clone
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.util.getCompleteToken

class RefreshTokenInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_REFRESH_TOKEN_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {

        val result = chain.proceed(chain.request)
        return if (result is Response.Failure) {
            if (result.error is AuthenticationError) {
                val authenticationResult =
                    chain.authenticator.refreshToken(result.error.repositoryId)
                if (authenticationResult is Response.Success) chain.retry(result.error.repositoryId)
                else authenticationResult
            } else result
        } else result
    }


    private suspend fun Interceptor.Chain.retry(repositoryId:String):Response<Any> {
        return proceed(request.clone(headers = request.headers + ("Authentication" to authenticator.getCompleteToken(repositoryId))))
    }

}