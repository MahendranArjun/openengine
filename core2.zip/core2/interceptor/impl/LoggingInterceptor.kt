package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response
import java.lang.IllegalArgumentException
import kotlin.Exception

class LoggingInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_LOGGING_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {

        val logger = chain.repository.httpDataLogger
        val request = chain.request
        return if (logger != null) {
            logger.request(request)
            chain.proceed(request)
                .onSuccess { logger.response(this, request) }
                .onFailure { logger.error(this, request) }
        } else chain.proceed(request)
    }


}