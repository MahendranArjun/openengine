package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response

class ServerCallInterceptor : Interceptor {
    override val id: String get() = Interceptor.ID_SERVER_INTERCEPTOR
    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {
        println("Interceptor = $id")
        @Suppress("UNCHECKED_CAST")
        return chain.call(chain.repository, chain.request)
    }
}