package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.request.Request.Companion.clone
import com.gboxz.http.core.response.Response
import java.lang.IllegalArgumentException

class SerializationInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_SERIALIZATION_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {
        val httpDataFormatter = chain.repository.httpDataFormatter?:throw IllegalArgumentException("No HttpDataFormatter provided")
        return chain.proceed(chain.request.clone(body = httpDataFormatter.serialize(chain.request.body, chain.request) ))
    }


}