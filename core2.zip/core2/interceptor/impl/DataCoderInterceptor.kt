package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.request.Request.Companion.clone
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.util.transformWithBody
import java.lang.IllegalArgumentException

class DataCoderInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_CODER_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {

        val httpDataCoder = chain.repository.httpDataCoder
            ?: throw IllegalArgumentException("No HttpDataFormatter provided")

        val request = chain.request.clone(
            body = httpDataCoder.encode(
                chain.request.body as String,
                chain.request
            )
        )
        return chain.proceed(request).transformWithBody {
            httpDataCoder.decode(it?.toString(), request)
        }
    }

}