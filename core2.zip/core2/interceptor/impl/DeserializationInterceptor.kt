package com.gboxz.http.core.interceptor.impl

import com.gboxz.http.core.interceptor.Interceptor
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.util.transformWithBody
import java.lang.IllegalArgumentException

class DeserializationInterceptor : Interceptor {

    override val id: String get() = Interceptor.ID_DESERIALIZATION_INTERCEPTOR

    override suspend fun intercept(chain: Interceptor.Chain): Response<Any> {
        val httpDataFormatter = chain.repository.httpDataFormatter?:throw IllegalArgumentException("No HttpDataFormatter provided")
        return chain.proceed(chain.request).transformWithBody{
            httpDataFormatter.deserialize(it?.toString(), chain.request)
        }
    }


}