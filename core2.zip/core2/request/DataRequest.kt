package com.gboxz.http.core.request

import com.gboxz.http.core.request.Request.Companion.createId
import com.gboxz.http.core.request.impl.DataRequestImpl
import com.gboxz.http.core.util.Headers
import com.gboxz.http.core.util.Params

interface DataRequest<out IN, out OUT> : Request<Any?> {
    override val body: IN?
    override val type: Class<out OUT>

    companion object {
        operator fun <IN, OUT> invoke(
            url: String,
            method: Request.Method,
            type: Class<out OUT>,
            body: IN? = null,
            id: String? = null,
            headers: Headers = emptyMap(),
            params: Params = emptyMap(),
            options: Request.Options = Request.Options()
        ): DataRequest<IN, OUT> =
            DataRequestImpl(
                id.createId(url, method),
                url,
                method,
                body,
                type,
                headers,
                params,
                options
            )
    }
}