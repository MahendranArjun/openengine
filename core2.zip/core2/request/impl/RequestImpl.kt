package com.gboxz.http.core.request.impl

import com.gboxz.http.core.request.Request
import com.gboxz.http.core.util.Headers
import com.gboxz.http.core.util.Params
import java.lang.reflect.Type

internal class RequestImpl(
    override val id: String,
    override val url: String,
    override val method: Request<Any?>.Method,
    override val body: Any?,
    override val type: Type,
    override val headers: Headers,
    override val params: Params,
    override val options: Request<Any?>.Options
) : Request<Any?>