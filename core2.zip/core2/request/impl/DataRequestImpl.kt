package com.gboxz.http.core.request.impl

import com.gboxz.http.core.request.DataRequest
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.util.Headers
import com.gboxz.http.core.util.Params
import java.lang.reflect.Type

internal class DataRequestImpl<IN, OUT>(
    override val id: String,
    override val url: String,
    override val method: Request<Any?>.Method,
    override val body: IN?,
    override val type: Class<out OUT>,
    override val headers: Headers,
    override val params: Params,
    override val options: Request<Any?>.Options
) : DataRequest<IN, OUT>