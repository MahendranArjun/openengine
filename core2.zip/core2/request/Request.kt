package com.gboxz.http.core.request

import com.gboxz.http.core.request.impl.RequestImpl
import com.gboxz.http.core.util.Headers
import com.gboxz.http.core.util.Params
import java.lang.reflect.Type

interface Request<T> {

    val id: String
    val url: String
    val method: Method
    val body: Any?
    val type: Type
    val headers: Headers
    val params: Params
    val options: Options


    data class Options(
        val timeout: Int = 30000,
        val repositoryId: String? = null,
        val reportLoading: Boolean = false,
        val withToken: Boolean = false,
        val requestHandlerOrder: List<Int> = emptyList(),
        val interceptorToSkip: List<String> = emptyList(),
        val extra: Any? = null
    )

    enum class Method {
        Get, Post, Put, Head, Delete, Patch
    }


    companion object {

        operator fun invoke(
            url: String,
            method: Method,
            type: Type,
            body: Any? = null,
            id: String? = null,
            headers: Headers = emptyMap(),
            params: Params = emptyMap(),
            options: Options = Options(),
        ): Request<Any?> =
            RequestImpl(id.createId(url, method), url, method, body, type, headers, params, options)


        internal fun String?.createId(url: String, method: Method) = this ?: "$method:$url"

        fun Request<Any?>.clone(
            id: String = this.id,
            url: String = this.url,
            method: Method = this.method,
            type: Type = this.type,
            body: Any? = this.body,
            headers: Headers = this.headers,
            params: Params = this.params,
            options: Options = this.options
        ): Request<Any?> = Request(url, method, type, body, id, headers, params, options)
    }

}