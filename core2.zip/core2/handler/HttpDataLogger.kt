package com.gboxz.http.core.handler

import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response

interface HttpDataLogger {
    fun request(request: Request<Any?>)
    fun response(response: Response.Success<Any>, request: Request<Any?>)
    fun error(error: Response.Failure, request: Request<Any?>)
}

