package com.gboxz.http.core.handler

import com.gboxz.http.core.request.Request


interface HttpDataCoder {
    fun encode(data:String?, request: Request<Any?>): String?
    fun decode(data:String?, request: Request<Any?>): String?
}