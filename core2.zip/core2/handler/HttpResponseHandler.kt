package com.gboxz.http.core.handler

import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response


interface HttpResponseHandler {
    fun response(response: Response.Success<Any>, request: Request<Any?>): Response.Success<Any>
    fun error(error: Response.Failure, request: Request<Any?>): Response.Failure
}