package com.gboxz.http.core.util

import com.gboxz.http.core.response.Response
import com.gboxz.http.core.response.Transformer

fun <S,R> Response<S>.transformWithBody(transformer: Transformer<S?,R?>):Response<R> {
    return when (this) {
        is Response.Success -> Response.Success(
            transformer.transform(body),
            networkResponse
        )
        is Response.Failure -> this
    }
}

fun <S,R> Response<S>.transform(transformer: Transformer<Response<S>,Response<R>>):Response<R> {
    return transformer.transform(this)
}

fun <S:Any,R:Any> Response<S>.transformIfNotNull(transformer: Transformer<Response<S>,Response<R>?>):Response<Any> {
    return transformer.transform(this) ?: this
}