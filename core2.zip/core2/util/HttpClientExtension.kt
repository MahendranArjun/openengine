package com.gboxz.http.core.util

import com.gboxz.http.core.client.HttpClient
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.Response



suspend inline fun <reified OUT> HttpClient.post(
    url: String,
    body: Any?,
    id: String? = null,
    headers: Headers = emptyMap(),
    params: Params = emptyMap(),
    options: Request.Options = Request.Options()
): Response<OUT> = post(url, body, OUT::class.java, id, headers, params, options)

suspend inline fun <reified OUT> HttpClient.put(
    url: String,
    body: Any?,
    id: String? = null,
    headers: Headers = emptyMap(),
    params: Params = emptyMap(),
    options: Request.Options = Request.Options()
): Response<OUT> = put(url, body, OUT::class.java, id, headers, params, options)

suspend inline fun <reified OUT> HttpClient.patch(
    url: String,
    body: Any?,
    id: String? = null,
    headers: Headers = emptyMap(),
    params: Params = emptyMap(),
    options: Request.Options = Request.Options()
): Response<OUT> = patch(url, body, OUT::class.java, id, headers, params, options)


suspend inline fun <reified OUT> HttpClient.get(
    url: String,
    id: String? = null,
    headers: Headers = emptyMap(),
    params: Params = emptyMap(),
    options: Request.Options = Request.Options()
): Response<OUT> = get(url,  OUT::class.java, id, headers, params, options)


suspend inline fun <reified OUT> HttpClient.delete(
    url: String,
    id: String? = null,
    headers: Headers = emptyMap(),
    params: Params = emptyMap(),
    options: Request.Options = Request.Options()
): Response<OUT> = delete(url,  OUT::class.java, id, headers, params, options)


suspend inline fun <reified OUT> HttpClient.head(
    url: String,
    id: String? = null,
    headers: Headers = emptyMap(),
    params: Params = emptyMap(),
    options: Request.Options = Request.Options()
): Response<OUT> = head(url,  OUT::class.java, id, headers, params, options)