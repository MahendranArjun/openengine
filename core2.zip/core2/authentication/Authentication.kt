package com.gboxz.http.core.authentication

import com.gboxz.http.core.response.Response

interface Authentication {

    val repositoryId:String
    val scheme:Scheme
    suspend fun authenticate(body:Any?) : Response<Result>


    enum class Scheme {
        Basic, Bearer, Digest, HOBA, Mutual, AWS4_HMAC_SHA256
    }

    interface Result {
        val associatedRepositoryIds: List<String>
        val token: String
    }
}