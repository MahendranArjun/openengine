package com.gboxz.http.core.authentication

import com.gboxz.http.core.authentication.Authentication
import com.gboxz.http.core.response.Response

interface OAuthentication : Authentication{
    suspend fun refreshToken(body:Any?): Response<Authentication.Result>
}