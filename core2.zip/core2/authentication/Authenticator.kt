package com.gboxz.http.core.authentication

import com.gboxz.http.core.response.Response


interface Authenticator {
    suspend fun authenticate(repositoryId: String, body: Any? = null): Response<Authentication.Result>
    suspend fun refreshToken(repositoryId: String, body: Any? = null): Response<Authentication.Result>
    fun getToken(repositoryId: String): String?
    fun getAuthentication(repositoryId: String): Authentication?
    fun dispose(repositoryId: String)
    fun disposeAll()
}