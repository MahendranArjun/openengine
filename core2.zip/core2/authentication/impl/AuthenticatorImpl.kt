package com.gboxz.http.core.authentication.impl

import com.gboxz.http.core.authentication.Authentication
import com.gboxz.http.core.authentication.Authenticator
import com.gboxz.http.core.authentication.OAuthentication
import com.gboxz.http.core.response.Response

internal class AuthenticatorImpl(private val authentications: List<Authentication>):
    Authenticator {


    private val tokens = mutableMapOf<String, String>()

    override suspend fun authenticate(
        repositoryId: String,
        body: Any?
    ): Response<Authentication.Result> =
        getAuthenticationNotNull(repositoryId).authenticate(body).withSaveToken()


    override suspend fun refreshToken(
        repositoryId: String,
        body: Any?
    ): Response<Authentication.Result> =
        getOAuthenticationNotNull(repositoryId).refreshToken(body).withSaveToken()


    override fun getToken(repositoryId: String): String? = tokens[repositoryId]
    override fun getAuthentication(repositoryId: String): Authentication? =
        authentications.find { it.repositoryId == repositoryId }

    override fun dispose(repositoryId: String) {
        tokens.remove(repositoryId)
    }

    override fun disposeAll() {
        tokens.clear()
    }


    private fun getAuthenticationNotNull(repositoryId: String): Authentication =
        getAuthentication(repositoryId) ?: throw IllegalArgumentException("Invalid repository id")


    private fun getOAuthenticationNotNull(repositoryId: String): OAuthentication =
        getAuthenticationNotNull(repositoryId).let {
            if (it is OAuthentication) it else throw IllegalArgumentException("Invalid repository id")
        }


    private fun Response<Authentication.Result>.withSaveToken(): Response<Authentication.Result> {
        if (this is Response.Success && body != null)
            body.associatedRepositoryIds.forEach { tokens[it] = body.token }
        return this
    }

}