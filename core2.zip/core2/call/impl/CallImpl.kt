package com.gboxz.http.core.call.impl

import com.gboxz.http.core.call.Call
import com.gboxz.http.core.request.Request
import com.gboxz.http.core.response.NetworkResponse
import com.gboxz.http.core.response.Response
import com.gboxz.http.core.server.Repository
import com.gboxz.http.core.util.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.*


internal class CallImpl : Call {

    private val httpClient = OkHttpClient.Builder()
        .build()

    override suspend fun invoke(repository: Repository, request: Request<Any?>): Response<String> {


        val builder = okhttp3.Request.Builder()

        val url = "${repository.baseUrl}${request.url}"
        builder.url(url)
        request.headers.forEach {
            builder.addHeader(it.key, it.value)
        }

        val body = request.body as String

        builder.method(request.method.toString().toUpperCase(Locale.getDefault()), body.toRequestBody())


        return withContext(Dispatchers.IO) {
            val response = httpClient.newCall(builder.build()).await()
            Response(
                response.body?.string(), NetworkResponse(url, response.headers.toMap(),
                    response.code,
                    response.message)
            )
        }
    }


}